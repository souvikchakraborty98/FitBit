# Arduino-Bluetooth-Basic
Control a LED using your smartphone via bluetooth
Download the app from here : http://goo.gl/PSXVoF

Tutorial : https://igniteinnovateideas.wordpress.com/2016/04/18/arduino-bluetooth-basic-tutorial/

Website : https://http://mayooghgirish.ml


